Splunk App for ClickHouse Cloud Audit Logs
==========================================

This Splunk modular input reads audit logs from the [ClickHouse Cloud API](https://clickhouse.com/docs/en/cloud/manage/api/api-overview).